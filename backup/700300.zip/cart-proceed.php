<?php
    include "./components/header.php";
    include "./components/page-header.php";
?>

<div class="container my-5">
    <?php
        include "./components/widget-cart-proceed.php";
    ?>
</div>

<div class="container my-5">
    <?php
        include "./components/widget-popular-more.php";
    ?>
</div>

<div class="container my-5">
    <?php
        include "./components/widget-advert.php";
    ?>
</div>


<div class="container my-5">
    <?php
        include "./components/page-footer.php";
    ?>
</div>


<?php
    include "./components/footer.php";
?>