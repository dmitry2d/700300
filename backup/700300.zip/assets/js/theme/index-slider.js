

$(document).ready(() => {

    $('.index-slider__items').slick({
        dots: true,
        prevArrow: $('.index-slider__prev'),
        nextArrow: $('.index-slider__next'),
        appendDots: $('.index-slider__dots')
    });

});