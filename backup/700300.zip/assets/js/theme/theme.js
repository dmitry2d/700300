

import './settings.js';
import './common.js';
import './main-menu.js';
import './index-slider.js';
