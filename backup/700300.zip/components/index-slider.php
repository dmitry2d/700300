
    <section class="index-slider">
    
        <div class="index-slider__items">
    
            <div class="index-slider__item">
                <img src="./assets/img/slider/pizza.jpg" alt="">
            </div>
            <div class="index-slider__item">
                <img src="./assets/img/slider/pirogi.jpg" alt="">
            </div>
            <div class="index-slider__item">
                <img src="./assets/img/slider/gruzia.jpg" alt="">
            </div>
    
        </div>

        <div class="index-slider__nav">
            <div class="index-slider__prev">
                <img src="./assets/img/slider/slider-arrow.png" alt="">
            </div>
            <div class="index-slider__next">
                <img src="./assets/img/slider/slider-arrow.png" alt="">
            </div>
        </div>
        <div class="index-slider__dots"></div>
    
    </section>