

<section class="catalogue py-4">

    <div class="row row-cols-2 row-cols-lg-3 row-cols-xl-4 fs-4 justify-content-center g-1">

        <div class="col">
            <a href="./catalogue-category.php" class="p-3 catalogue-item">
                <div class="catalogue-image">
                    <img src="./assets/img/temp_/cat01.png">
                </div>
                <div class="catalogue-title">
                    Пицца
                </div>
            </a>
        </div>
        

        <div class="col">
            <a href="" class="p-3 catalogue-item">
                <div class="catalogue-image">
                    <img src="./assets/img/temp_/cat02.png">
                </div>
                <div class="catalogue-title">
                    Суши и роллы
                </div>
            </a>
        </div>
        

        <div class="col">
            <a href="" class="p-3 catalogue-item">
                <div class="catalogue-image">
                    <img src="./assets/img/temp_/cat03.png">
                </div>
                <div class="catalogue-title">
                    Комбо
                </div>
            </a>
        </div>

        <div class="col">
            <a href="" class="p-3 catalogue-item">
                <div class="catalogue-image">
                    <img src="./assets/img/temp_/cat04.png">
                </div>
                <div class="catalogue-title">
                    Вок
                </div>
            </a>
        </div>

        <div class="col">
            <a href="" class="p-3 catalogue-item">
                <div class="catalogue-image">
                    <img src="./assets/img/temp_/cat05.png">
                </div>
                <div class="catalogue-title">
                    Поке
                </div>
            </a>
        </div>

        <div class="col">
            <a href="" class="p-3 catalogue-item">
                <div class="catalogue-image">
                    <img src="./assets/img/temp_/cat06.png">
                </div>
                <div class="catalogue-title">
                    Грузия
                </div>
            </a>
        </div>
        

    </div>

</section>