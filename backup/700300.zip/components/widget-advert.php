<section class="advert">

    <div class="row justify-content-center g-0">
        <div class="col">
            <div class="text-center">
                <img src="./assets/img/tags/mb_01.png" height="53">
            </div>
        </div>
        
        <div class="col">
            <div class="text-center">
                <img src="./assets/img/tags/mb_02.png" height="53">
            </div>
        </div>
        
        <div class="col">
            <div class="text-center">
                <img src="./assets/img/tags/mb_03.png" height="53">
            </div>
        </div>
        
        <div class="col">
            <div class="text-center">
                <img src="./assets/img/tags/mb_04.png" height="53">
            </div>
        </div>
        
        <div class="col">
            <div class="text-center">
                <img src="./assets/img/tags/mb_07.png" height="53">
            </div>
        </div>
        
    </div>

    <div class="my-4 advert-banner">
        <a href="" class="w-100">
            <img src="./assets/img/banners/b_banner1.jpg" class="img-cover">
        </a>
    </div>

</section>