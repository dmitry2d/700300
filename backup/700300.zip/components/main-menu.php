
<section class="main-menu">

    <div class="container">

        <div class="main-menu-items">
            <a href="./catalogue-category.php" class="active">Пицца</a>
            <a href="./catalogue-category.php">Суши и роллы</a>
            <a href="./catalogue-category.php">Комбо</a>
            <a href="./catalogue-category.php">Вок</a>
            <a href="./catalogue-category.php">Поке</a>
            <a href="./catalogue-category.php">Грузия</a>
            <a href="./catalogue-category.php">Напитки</a>
            <a href="./catalogue-category.php">Закуски</a>
            <a href="./catalogue-category.php">Салаты</a>
            <a href="./catalogue-category.php">Десерты</a>
            <a href="./catalogue-category.php">Супы</a>
            <a href="./catalogue-category.php">Завтраки</a>
            <a href="./catalogue-category.php">Пироги</a>
            <a href="./catalogue-category.php">Пасты и Горячие блюда</a>
            <a href="./catalogue-category.php">Детское меню</a>
            <a href="./catalogue-category.php">Ланч-Комбо</a>
        </div>

        <div class="main-menu-close">
            <i class="fa fa-times" aria-hidden="true"></i>
        </div>
        

    </div>

</section>